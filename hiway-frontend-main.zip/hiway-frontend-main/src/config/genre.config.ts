export const Genre = [
	{
		label: 'Comedy',
		value: 'comedy'
	},
	{
		label: 'Horror',
		value: 'horror'
	},
	{
		label: 'Action',
		value: 'action'
	},
	{
		label: 'Sci-Fi',
		value: 'sci-fi'
	},
	{
		label: 'Drama',
		value: 'drama'
	}
];
