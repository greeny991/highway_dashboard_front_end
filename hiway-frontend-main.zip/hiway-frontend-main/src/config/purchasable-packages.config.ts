export const PurchasablePackages = [
	{
		packageName: 'STARTER PACKAGE',
		packageDescription: '50 GB STORAGE / 250 HR STREAMS',
		price: 75
	},
	{
		packageName: 'ADDITIONAL STREAM HOURS',
		packageDescription: '+150 hours',
		price: 60
	},
	{
		packageName: 'ADDITIONAL STORAGE SPACE',
		packageDescription: '+50 GB',
		price: 20
	}
];
