export enum PublicationType {
	PAID = 'PAID',
	FREE = 'FREE'
}
