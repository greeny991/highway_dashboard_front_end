export const EpisodicContentType = [
	{
		label: 'Episodic',
		value: 'true'
	},
	{
		label: 'Non-episodic',
		value: 'false'
	}
];
