export const Rating = [
	{
		label: 'U',
		value: 'U'
	},
	{
		label: 'PG',
		value: 'PG'
	},
	{
		label: '12A',
		value: '12A'
	},
	{
		label: '12',
		value: '12'
	},
	{
		label: '15',
		value: '15'
	},
	{
		label: '18',
		value: '18'
	},
	{
		label: 'R18',
		value: 'R18'
	}
];
