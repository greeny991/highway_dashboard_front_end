export const ContentType = [
	{
		label: 'Commercial',
		value: 'commercial'
	},
	{
		label: 'Documentary',
		value: 'documentary'
	},
	{
		label: 'Episode',
		value: 'episode'
	},
	{
		label: 'Feature',
		value: 'feature'
	},
	{
		label: 'Promo',
		value: 'promo'
	},
	{
		label: 'Trailer',
		value: 'trailer'
	}
];
