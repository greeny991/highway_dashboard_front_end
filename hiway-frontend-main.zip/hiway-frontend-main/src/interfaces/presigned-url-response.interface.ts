export interface PresignedUrlResponse {
	uploadUrl: string;
	fileUrl: string;
}
