export interface IContentFabricFile {
	path: string;
	mime_type: string;
	size: any;
	data: File;
}
