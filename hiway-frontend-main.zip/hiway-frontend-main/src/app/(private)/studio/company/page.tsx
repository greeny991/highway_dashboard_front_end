'use client';

import { redirect } from 'next/navigation';

export default function CompanyPage() {
	redirect('/studio/media-catalogue');
}
