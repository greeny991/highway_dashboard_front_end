'use client';

import { redirect } from 'next/navigation';

export default function PublicationPage() {
	redirect('/studio/publications-catalogue');
}
