'use client';

import { redirect } from 'next/navigation';

export default function MediaPage() {
	redirect('/studio/media-catalogue');
}
