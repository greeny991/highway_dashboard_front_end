'use client';

import { redirect } from 'next/navigation';

export default function StudioPage() {
	redirect('/studio/media-catalogue');
}
