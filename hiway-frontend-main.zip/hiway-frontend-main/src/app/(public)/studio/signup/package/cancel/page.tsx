'use client';

import { CompanyPackageWidget } from '@/widgets/company-package.widget';

export default function CompanyPackageCancelPage() {
	return <CompanyPackageWidget cancel={true} />;
}
