'use client';

import { CompanyPackageWidget } from '@/widgets/company-package.widget';

export default function CompanyPackagePage() {
	return <CompanyPackageWidget />;
}
